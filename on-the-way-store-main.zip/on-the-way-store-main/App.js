import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>On The Way Store</h1>
      <p>배포가 성공적으로 되었습니다!</p>
    </div>
  );
}

export default App;
